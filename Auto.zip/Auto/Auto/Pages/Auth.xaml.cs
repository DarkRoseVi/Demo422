﻿using Auto.DataBase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Auto.Pages
{
    /// <summary>
    /// Логика взаимодействия для Auth.xaml
    /// </summary>
    public partial class Auth : Page
    {
        public Auth()
        {
            InitializeComponent();
        }

        private void AuthButton_Click(object sender, RoutedEventArgs e)
        {
            Client client = App.db.Client.FirstOrDefault(x => x.FullName == FIO.Text && x.PhoneNumber == number.Text);
            Mechanic me = App.db.Mechanic.FirstOrDefault(x => x.FullName == FIO.Text);
            if (client != null)
            {
                App.cl = client;
                App.main.myFrame.NavigationService.Navigate(new ClientPage());
            }
            else if (me != null)
            {
                App.mechanic = me;
                App.main.myFrame.NavigationService.Navigate(new Pages.ListCar());
            }
            else
            {
                MessageBox.Show("Пльзователя нет");
            }

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            App.main.myFrame.NavigationService.Navigate(new Pages.Registr());
        }
    }
}
