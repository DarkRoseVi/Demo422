﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Auto.Pages
{
    /// <summary>
    /// Логика взаимодействия для ClientPage.xaml
    /// </summary>
    public partial class ClientPage : Page
    {
        public ClientPage()
        {
            InitializeComponent();
            int carid = App.cl.Car.ToList().Last().CarID;
            RepairRequest.ItemsSource = App.db.RequestRepair.Where(x => x.CarID == carid).ToList();
        }

        private void RepairRequest_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
