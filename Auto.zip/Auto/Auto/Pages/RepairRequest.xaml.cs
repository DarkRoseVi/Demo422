﻿using Auto.DataBase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Auto.Pages
{
    /// <summary>
    /// Логика взаимодействия для RepairRequest.xaml
    /// </summary>
    public partial class RepairRequest : Page
    {
        public RequestRepair repairReguest;
        public RepairRequest(RequestRepair _repairReguest)
        {
            InitializeComponent();
            repairReguest = _repairReguest;
            CarsName.Text = _repairReguest.Car.Model;
            MaterialComboBox.ItemsSource = App.db.Part.ToList();


        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            App.main.myFrame.NavigationService.GoBack();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                RepairAssignment ra = null;
                var selpart = MaterialComboBox.SelectedItem as Part;
                if (App.db.RepairAssignment.FirstOrDefault(x => x.RequestRepair.RequestID == repairReguest.RequestID) != null)
                {
                    ra.RequestID = repairReguest.RequestID;
                    ra.MechanicID = App.mechanic.MechanicID;
                    ra.CompletionDate = CompletionDatePicker.SelectedDate;
                    ra.Status = "Готово";
                }
                else
                {
                    ra = App.db.RepairAssignment.Add(new RepairAssignment() { RequestID = repairReguest.RequestID, MechanicID = App.mechanic.MechanicID, CompletionDate = CompletionDatePicker.SelectedDate, Status = "Готово" });
                }

                App.db.RepairPart.Add(new RepairPart() { AssignmentID = ra.AssignmentID, PartID = selpart.PartID, Quantity = int.Parse(QuantityTextBox.Text) });
                App.db.Report.Add(new Report() { AssignmentID = ra.AssignmentID, ReportDate = DateTime.Now, WorkDescription = WorkDescriptionTextBox.Text, TotalCost = decimal.Parse(coust.Text), HoursSpent = decimal.Parse(HoursSpentTextBox.Text) });
                App.db.SaveChanges();
                MessageBox.Show("Успешно");
                App.main.myFrame.NavigationService.GoBack();

            }
            catch
            {
                MessageBox.Show("Проверти данные");
            }

        }
    }
}
