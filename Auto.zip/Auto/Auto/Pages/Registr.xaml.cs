﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Auto.Pages
{
    /// <summary>
    /// Логика взаимодействия для Registr.xaml
    /// </summary>
    public partial class Registr : Page
    {
        public Registr()
        {
            InitializeComponent();
        }
        private void SubmitButton_Click(object sender, RoutedEventArgs e)
        {
            // Получение данных из полей
            string fullName = FullNameTextBox.Text;
            string phone = PhoneTextBox.Text;
            string carMake = CarMakeTextBox.Text;
            string carModel = CarModelTextBox.Text;
            string carYear = CarYearTextBox.Text;
            string problemDescription = ProblemDescriptionTextBox.Text;

            // Валидация данных
            if (string.IsNullOrEmpty(fullName) || string.IsNullOrEmpty(phone) ||
                string.IsNullOrEmpty(carMake) || string.IsNullOrEmpty(carModel) ||
                string.IsNullOrEmpty(carYear) || string.IsNullOrEmpty(problemDescription))
            {
                MessageBox.Show("Заполните все поля!");
                return;
            }

            // Логика сохранения данных (заглушка)
            MessageBox.Show("Заявка отправлена:\n" +
                           $"ФИО: {fullName}\n");
            DataBase.Client cl = App.db.Client.Add(new DataBase.Client() { FullName = fullName, PhoneNumber = phone });
            App.cl = cl;
            DataBase.Car car = App.db.Car.Add(new DataBase.Car() { ClientID = cl.ClientID, Make = carMake, Model = carModel, Year = int.Parse(carYear), });
            App.db.RequestRepair.Add(new DataBase.RequestRepair() { CarID = car.CarID, Description = problemDescription });
            MessageBox.Show("Сохранено");
            App.db.SaveChanges();
            App.main.myFrame.NavigationService.Navigate(new ClientPage());


        }
    }
}
