﻿using Auto.DataBase;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace Auto
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static MainWindow main;
        public static DataBase.AvtoEntities db = new DataBase.AvtoEntities();
        public static Mechanic mechanic;
        public static Client cl;
    }
}
