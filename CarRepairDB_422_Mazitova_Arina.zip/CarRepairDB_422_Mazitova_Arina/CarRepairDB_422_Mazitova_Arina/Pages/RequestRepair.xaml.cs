﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using CarRepairDB_422_Mazitova_Arina.Databases;

namespace CarRepairDB_422_Mazitova_Arina.Pages
{
    public partial class RequestRepair : Page
    {
        public RequestRepair()
        {
            InitializeComponent();
        }

        private void SaveRequest_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtFullName.Text) ||
                    string.IsNullOrWhiteSpace(txtPhoneNumber.Text) ||
                    string.IsNullOrWhiteSpace(txtMake.Text) ||
                    string.IsNullOrWhiteSpace(txtModel.Text) ||
                    string.IsNullOrWhiteSpace(txtYear.Text) ||
                    string.IsNullOrWhiteSpace(txtDescription.Text))
                {
                    txtMessage.Text = "Все поля должны быть заполнены!";
                    return;
                }

                string[] nameParts = txtFullName.Text.Split(' ');
                if (nameParts.Length < 2)
                {
                    txtMessage.Text = "Введите ФИО полностью (Имя Фамилия).";
                    return;
                }

                string firstName = nameParts[0];
                string lastName = nameParts[1];

                var existingCustomer = App.db.Customers.FirstOrDefault(c => c.PhoneNumber == txtPhoneNumber.Text);
                int customerId;

                if (existingCustomer == null)
                {
                    Customers newCustomer = new Customers
                    {
                        FirstName = firstName,
                        LastName = lastName,
                        PhoneNumber = txtPhoneNumber.Text,
                        RoleID = 1

                    };
                    App.db.Customers.Add(newCustomer);
                    App.db.SaveChanges();
                    customerId = newCustomer.CustomerID;
                }
                else
                {
                    customerId = existingCustomer.CustomerID;
                }

                Vehicles newVehicle = new Vehicles
                {
                    CustomerID = customerId,
                    Make = txtMake.Text,
                    Model = txtModel.Text,
                    Years = int.Parse(txtYear.Text)
                };
                App.db.Vehicles.Add(newVehicle);
                App.db.SaveChanges();

                Requests newRequest = new Requests
                {
                    VehicleID = newVehicle.VehicleID,
                    RequestDate = DateTime.Now,
                    Description = txtDescription.Text,
                    RequestStatusID = 6, 
                    AssignedEmployeeID = null, 
                    CompletionDate = null
                };

                App.db.Requests.Add(newRequest);
                App.db.SaveChanges();

                txtMessage.Text = "Заявка успешно сохранена!";
               
                ClearFields();
            }
            catch (Exception ex)
            {
                txtMessage.Text = "Ошибка: " + ex.Message;
            }
        }

        private void ClearFields_Click(object sender, RoutedEventArgs e)
        {
            ClearFields();
        }

        private void ClearFields()
        {
            txtFullName.Text = "";
            txtPhoneNumber.Text = "";
            txtMake.Text = "";
            txtModel.Text = "";
            txtYear.Text = "";
            txtDescription.Text = "";
            txtMessage.Text = "";
        }
    }
}