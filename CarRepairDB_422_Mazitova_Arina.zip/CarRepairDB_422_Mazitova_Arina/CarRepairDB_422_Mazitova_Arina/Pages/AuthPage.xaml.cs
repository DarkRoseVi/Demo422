﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using CarRepairDB_422_Mazitova_Arina.Databases;

namespace CarRepairDB_422_Mazitova_Arina.Pages
{
    /// <summary>
    /// Логика взаимодействия для AuthPage.xaml
    /// </summary>
    public partial class AuthPage : Page
    {
        public AuthPage()
        {
            InitializeComponent();
        }

        private void LoginBtn_Click(object sender, RoutedEventArgs e)
        {
            Users user = App.db.Users.FirstOrDefault(x => x.Username == logintb.Text && x.Password == passwordtb.Text);
            if (user != null)
            {
                App.currentUser = user;
                if (user.RoleID == 1)
                {
                    NavigationService.Navigate(new RequestRepair());
                    MessageBox.Show("Добро пожаловать");
                }
                if(user.RoleID == 2)
                {
                    NavigationService.Navigate(new RegistrationRequestPage());
                    MessageBox.Show("Добро пожаловать");
                }
            }
        }

        private void RegBtn_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new RegPage());

        }
    }
}
