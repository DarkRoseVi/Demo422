﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace CarRepairDB_422_Mazitova_Arina.Pages
{
    public partial class RegistrationRequestPage : Page
    {
        public RegistrationRequestPage()
        {
            InitializeComponent();
            LoadRequests();
        }

        private void LoadRequests()
        {
            dgRequests.ItemsSource = App.db.Requests.ToList();
        }

        private void dgRequests_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dgRequests.SelectedItem != null)
            {
                dynamic selectedRequest = dgRequests.SelectedItem;


                txtVehicle.Text = selectedRequest.Vehicles.Model;
                txtDescription.Text = selectedRequest.Description;
                txtStatus.Text = selectedRequest.RequestStatuses.StatusName;
            }
        }

        private void AcceptRequest_Click(object sender, RoutedEventArgs e)
        {
            if (dgRequests.SelectedItem == null)
            {
                txtMessage.Text = "Выберите заявку!";
                return;
            }

            try
            {
                dynamic selectedRequest = dgRequests.SelectedItem;
                int requestId = selectedRequest.RequestID;

                var request = App.db.Requests.FirstOrDefault(r => r.RequestID == requestId);
                if (request != null)
                {
                    request.RequestStatusID = 1;  
                    App.db.SaveChanges();
                    LoadRequests();
                    txtMessage.Text = "Заявка принята.";
                }
            }
            catch (Exception ex)
            {
                txtMessage.Text = "Ошибка обновления заявки: " + ex.Message;
            }
        }

        private void RejectRequest_Click(object sender, RoutedEventArgs e)
        {
            if (dgRequests.SelectedItem == null)
            {
                txtMessage.Text = "Выберите заявку!";
                return;
            }

            try
            {
                dynamic selectedRequest = dgRequests.SelectedItem;
                int requestId = selectedRequest.RequestID;

                var request = App.db.Requests.FirstOrDefault(r => r.RequestID == requestId);
                if (request != null)
                {
                    request.RequestStatusID = 5;  
                    App.db.SaveChanges();
                    LoadRequests();
                    txtMessage.Text = "Заявка отклонена.";
                }
            }
            catch (Exception ex)
            {
                txtMessage.Text = "Ошибка обновления заявки: " + ex.Message;
            }
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            dgRequests.ItemsSource = App.db.Requests.ToList();

        }
    }
}