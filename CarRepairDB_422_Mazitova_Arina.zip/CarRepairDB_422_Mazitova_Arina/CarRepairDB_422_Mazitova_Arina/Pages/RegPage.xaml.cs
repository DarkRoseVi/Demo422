﻿using CarRepairDB_422_Mazitova_Arina.Databases;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CarRepairDB_422_Mazitova_Arina.Pages
{
    /// <summary>
    /// Логика взаимодействия для RegPage.xaml
    /// </summary>
    public partial class RegPage : Page
    {
        Users user = new Users();
        public RegPage()
        {
            InitializeComponent();
        }

       

        private void RegBtn_Click(object sender, RoutedEventArgs e)
        {
            user.Username = txtUsername.Text;
            user.Password = txtPassword.Password;
            user.Email = txtEmail.Text;
            user.RoleID = 1;
            App.db.Users.Add(user);

            App.db.SaveChanges();
            MessageBox.Show("Вы зарегистрированы!");
            NavigationService.Navigate(new AuthPage());
            
        }
    }
}
