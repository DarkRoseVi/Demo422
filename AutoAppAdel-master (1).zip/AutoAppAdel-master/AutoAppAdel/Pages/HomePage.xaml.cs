﻿using AutoAppAdel.Components;
using AutoAppAdel.Pages.ClientPages;
using AutoAppAdel.Pages.Mechanic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AutoAppAdel.Pages
{
    /// <summary>
    /// Логика взаимодействия для HomePage.xaml
    /// </summary>
    public partial class HomePage : Page
    {
        User user;
        public HomePage(User user)
        {
            InitializeComponent();
            this.user = user;
            App.homeFrame = this.homeFrame;
            switch (user.Role_Id)
            {
                case 1:
                    RequestsBtn.Visibility = Visibility.Visible;
                    break;
                case 2:
                    RequestBtn.Visibility = Visibility.Visible;
                    EditClientBtn.Visibility = Visibility.Visible;
                    break;
                case 3:
                    MechanicBtn.Visibility = Visibility.Visible;
                    break;
            }
        }

        private void ExitBtn_Click(object sender, RoutedEventArgs e)
        {
            App.mainFrame.Navigate(new Uri("Pages/AuthPage.xaml", UriKind.Relative));
        }

        private void RequestsBtn_Click(object sender, RoutedEventArgs e)
        {
            homeFrame.Navigate(new Uri("Pages/OperatorPages/RequestsPage.xaml", UriKind.Relative));
        }

        private void RequestBtn_Click(object sender, RoutedEventArgs e)
        {
            homeFrame.Navigate(new AddRequestPage(user));
        }

        private void EditClientBtn_Click(object sender, RoutedEventArgs e)
        {
            homeFrame.Navigate(new EditClientInfoPage(user));
        }

        private void MechanicBtn_Click(object sender, RoutedEventArgs e)
        {
            homeFrame.Navigate(new MechanicRequestsPage(user));
        }
    }
}
