﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AutoAppAdel.Pages
{
    /// <summary>
    /// Логика взаимодействия для AuthPage.xaml
    /// </summary>
    public partial class AuthPage : Page
    {
        public AuthPage()
        {
            InitializeComponent();
        }

        private void EnterBtn_Click(object sender, RoutedEventArgs e)
        {
            string login = LoginTb.Text;
            string password = PasswordTb.Password;
            if(CheckFields(login, password))
            {
                App.mainFrame.Navigate(new HomePage(App.db.User.First(x => x.Login == login && x.Password == password)));
            }
            else
            {
                MessageBox.Show("Логин или пароль неверны");
            }
        }

        private bool CheckFields(string login, string password)
        {
            if(string.IsNullOrEmpty(login) && string.IsNullOrEmpty(password))
            {
                return false;
            }
            if(App.db.User.Any(x=>x.Login == login && x.Password == password))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
