﻿using AutoAppAdel.Components;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AutoAppAdel.Pages.OperatorPages
{
    /// <summary>
    /// Логика взаимодействия для AcceptRequestPage.xaml
    /// </summary>
    public partial class AcceptRequestPage : Page
    {
        Request request;
        public AcceptRequestPage(Request request)
        {
            InitializeComponent();
            this.request = request;
            this.DataContext = request;
            MechanicCb.ItemsSource = App.db.Mechanic.ToList();
        }

        private void AcceptBtn_Click(object sender, RoutedEventArgs e)
        {
            if(MechanicCb.SelectedItem != null)
            {
                MessageBox.Show("Заявка принята!");
                request.Mechanic = MechanicCb.SelectedItem as Components.Mechanic;
                App.db.SaveChanges();
                App.homeFrame.Navigate(new RequestsPage());
            }
            else
            {
                MessageBox.Show("Выберите механика!");
            }
        }
    }
}
