﻿using AutoAppAdel.Components;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AutoAppAdel.Pages.OperatorPages
{
    /// <summary>
    /// Логика взаимодействия для RequestsPage.xaml
    /// </summary>
    public partial class RequestsPage : Page
    {
        public RequestsPage()
        {
            InitializeComponent();
            Refresh();
        }

        private void Refresh()
        {
            var requests = App.db.Request.ToList();
            ListView.ItemsSource = null;
            ListView.ItemsSource = requests;
        }

        private void AcceptBtn_Click(object sender, RoutedEventArgs e)
        {
            var btn = sender as Button;
            var request = btn.DataContext as Request;
            App.homeFrame.Navigate(new AcceptRequestPage(request));
        }
    }
}
