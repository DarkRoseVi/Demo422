﻿using AutoAppAdel.Components;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AutoAppAdel.Pages.Mechanic
{
    /// <summary>
    /// Логика взаимодействия для MechanicRequestsPage.xaml
    /// </summary>
    public partial class MechanicRequestsPage : Page
    {
        User user;
        public MechanicRequestsPage(User user)
        {
            InitializeComponent();
            this.user = user;
            var request = App.db.Request.Where(x => x.Mechanic.User_Id == user.Id).ToList();

            ListView.ItemsSource = request;
        }

    }
}
