﻿using AutoAppAdel.Components;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AutoAppAdel.Pages.ClientPages
{
    /// <summary>
    /// Логика взаимодействия для EditClientInfoPage.xaml
    /// </summary>
    public partial class EditClientInfoPage : Page
    {
        User user;
        public EditClientInfoPage(User user)
        {
            InitializeComponent();
            this.user = user;
            this.DataContext = App.db.Client.First(x=>x.User_Id == user.Id);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            App.db.SaveChanges();
        }
    }
}
