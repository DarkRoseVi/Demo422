﻿using AutoAppAdel.Components;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AutoAppAdel.Pages.ClientPages
{
    /// <summary>
    /// Логика взаимодействия для AddRequestPage.xaml
    /// </summary>
    public partial class AddRequestPage : Page
    {
        Request request;
        User user;
        public AddRequestPage(User user)
        {
            InitializeComponent();
            if (App.db.Request.Any(x => x.Client.User_Id == user.Id))
            {
                request = App.db.Request.First(x => x.Client.User_Id == user.Id);
            }
            else
            {
                request = new Request();
            }
            this.user = user;
            this.DataContext = request;
            ModelCb.ItemsSource = App.db.Auto.ToList();
        }

        private void SaveBtn_Click(object sender, RoutedEventArgs e)
        {
            if (!App.db.Request.Any(x => x.Client.User_Id == user.Id))
            {
                request.Client = App.db.Client.First(x => x.User_Id == user.Id);
                App.db.Request.Add(request);
                MessageBox.Show("Заявка оставлена!");
            }
            App.db.SaveChanges();
        }
    }
}
