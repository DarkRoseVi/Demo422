﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoAppAdel.Components
{
    public partial class Request
    {
        public bool isAccepted;
    }
}
