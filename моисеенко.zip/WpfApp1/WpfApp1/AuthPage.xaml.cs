﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для AuthPage.xaml
    /// </summary>
    public partial class AuthPage : Page
    {
        public AuthPage()
        {
            InitializeComponent();
        }
        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string phoneNumber = PhoneNumberTextBox.Text;

            if (string.IsNullOrWhiteSpace(phoneNumber))
            {
                MessageTextBlock.Text = "Введите номер телефона.";
                return;
            }

            var client = App.db.Clients.FirstOrDefault(c => c.PhoneNumber == phoneNumber);
            if (client != null)
            {
                MessageTextBlock.Text = string.Empty;
                СlientPage clientPage = new СlientPage(client);
                NavigationService.Navigate(new СlientPage(client));

            }

            var mechanic = App.db.Technicians.FirstOrDefault(m => m.PhoneNumber == phoneNumber);
            if (mechanic != null)
            {
                MessageTextBlock.Text = string.Empty;
                TechnicianPage mechanicPage = new TechnicianPage(mechanic);
                NavigationService.Navigate(new TechnicianPage(mechanic));
                return;
            }
        }
    }
}