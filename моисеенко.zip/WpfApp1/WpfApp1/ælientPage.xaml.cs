﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для СlientPage.xaml
    /// </summary>
    public partial class СlientPage : Page
    {
        private Clients _client;
       public СlientPage(Clients client)
        {
            InitializeComponent();
            _client = client;
        }

        private void SubmitButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
               

           

                MessageBox.Show("Заявка успешно отправлена!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Произошла ошибка при отправке заявки: " + ex.Message);
            }
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
           
        }
    }
}
