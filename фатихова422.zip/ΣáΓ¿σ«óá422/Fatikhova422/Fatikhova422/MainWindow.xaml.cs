﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Fatikhova422
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            _context = new AppDbContext();
            LoadRequests();
        }

        private void LoadRequests()
        {
            var requests = _context.Requests.ToList();
            RequestsListView.ItemsSource = requests;
        }

        private void AddRequestButton_Click(object sender, RoutedEventArgs e)
        {
            var client = new Client
            {
                ФИО = ClientNameTextBox.Text,
                Номер_телефона = PhoneNumberTextBox.Text
            };

            _context.Clients.Add(client);
            _context.SaveChanges();

            var request = new Request
            {
                ID_Клиента = client.ID_Клиента,
                Вид_автомобиля = CarTypeTextBox.Text,
                Модель = CarModelTextBox.Text,
                Описание_проблемы = ProblemDescriptionTextBox.Text,
                Дата_создания = DateTime.Now,
                Статус = "Новая"
            };

            _context.Requests.Add(request);
            _context.SaveChanges();

            LoadRequests();
        }
    
    }
}
