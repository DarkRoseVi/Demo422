﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lorina
{
    // Models/Client.cs
    public class Client
    {
        public int ClientID { get; set; }
        public string FullName { get; set; }
        public string PhoneNumber { get; set; }
        public string OtherContactInfo { get; set; }
    }

    // Models/Vehicle.cs
    public class Vehicle
    {
        public int VehicleID { get; set; }
        public int ClientID { get; set; }
        public string Make { get; set; }
        public string Model { get; set; }
        public int? Year { get; set; }
        public string VIN { get; set; }
        public string OtherVehicleInfo { get; set; }
    }

    // Models/RepairRequest.cs
    public class RepairRequest
    {
        public int RequestID { get; set; }
        public int VehicleID { get; set; }
        public DateTime RequestDate { get; set; }
        public string Description { get; set; }
        public string Status { get; set; }
        public int? Priority { get; set; }
        public int? AssignedMechanicID { get; set; }
        public DateTime? CompletionDate { get; set; }
        public string Report { get; set; }
    }

    // Models/Mechanic.cs
    public class Mechanic
    {
        public int MechanicID { get; set; }
        public string FullName { get; set; }
        public string Specialization { get; set; }
        public string ContactInfo { get; set; }
    }

    // Models/SparePart.cs
    public class SparePart
    {
        public int PartID { get; set; }
        public string PartName { get; set; }
        public string Description { get; set; }
        public decimal Price
        {
            get; set;
        }
    }
}