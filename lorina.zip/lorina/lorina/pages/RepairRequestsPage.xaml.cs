﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace lorina.pages
{
    /// <summary>
    /// Логика взаимодействия для RepairRequestsPage.xaml
    /// </summary>
    public partial class RepairRequestsPage : Page
    {
       

        public RepairRequestsPage()
        {
            InitializeComponent();
          
            LoadRepairRequests();
        }

        private void LoadRepairRequests()
        {
            
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Функциональность добавления еще не реализована."); // Заглушка
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            RepairRequest selectedRequest = (RepairRequest)RepairRequestsDataGrid.SelectedItem;
            if (selectedRequest != null)
            {
                MessageBox.Show($"Функциональность редактирования еще не реализована для заявки с ID: {selectedRequest.RequestID}"); // Заглушка
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите заявку для редактирования.");
            }
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            RepairRequest selectedRequest = (RepairRequest)RepairRequestsDataGrid.SelectedItem;
            if (selectedRequest != null)
            {
                MessageBox.Show($"Функциональность удаления еще не реализована для заявки с ID: {selectedRequest.RequestID}"); // Заглушка
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите заявку для удаления.");
            }
        }
    }
}