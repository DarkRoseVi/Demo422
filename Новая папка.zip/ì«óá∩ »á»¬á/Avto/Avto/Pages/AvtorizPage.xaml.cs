﻿using System;
using Avto.BD;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Avto.Pages
{
    /// <summary>
    /// Логика взаимодействия для AvtorizPage.xaml
    /// </summary>
    public partial class AvtorizPage : Page
    {

        public AvtorizPage()
        {
            InitializeComponent();
        }

        private void AvtorizBtn_Click(object sender, RoutedEventArgs e)
        {
            if (LoginTB.Text != "" && PassTB.Text != "")
            {
                if (LoginTB.Text == "м")
                {
                    App.Role = "м";
                    var mex = App.bd.Mexanik.FirstOrDefault(z => z.Password == PassTB.Text);
                    if (mex != null)
                    {
                        App.ID = mex.IDMexanik;
                        NavigationService.Navigate(new MexPage());
                    }
                }
                if (LoginTB.Text == "к")
                {
                    App.Role = "к";
                    var kl = App.bd.Client.FirstOrDefault(z => z.Password == PassTB.Text);
                    if (kl != null)
                    {
                        App.ID = kl.IDClient;
                        NavigationService.Navigate(new ClientZakazListPage());
                    }
                }
                if (LoginTB.Text == "о")
                {
                    App.Role = "о";
                    var op = App.bd.Operator.FirstOrDefault(z => z.Password == PassTB.Text);
                    if (op != null)
                    {
                        App.ID = op.IDOperator;
                        NavigationService.Navigate(new OperPage());
                    }
                }


            }
            else
            {
                MessageBox.Show("Заполните все данные");
            }
        }
    }
}
