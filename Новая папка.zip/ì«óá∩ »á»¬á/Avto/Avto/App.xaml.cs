﻿using Avto.BD;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace Avto
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static CarAvtoBDEntities bd = new CarAvtoBDEntities();
        public static string Role;
        public static int ID;
    }
}
